from moviepy.editor import VideoFileClip

videoClip = VideoFileClip("BlueTooth poker 8 Intro.mp4")

videoClip.write_gif("BlueToothPoker8Intro.gif")
